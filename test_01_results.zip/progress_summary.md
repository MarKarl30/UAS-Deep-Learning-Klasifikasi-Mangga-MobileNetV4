# Ringkasan hasil awal — Klasifikasi Kematangan Mangga

Anggota: Felix Ferdinad, Melvyn Benaya Wijaya | NIM: 535230123, 535230047

URL Colab: Belum diisi

Dataset: Mashkoor & Hakim (2024), Mango Shelf-Life Dataset V1. https://data.mendeley.com/datasets/rk4mm635rn/1

DOI: 10.17632/rk4mm635rn.1 | Lisensi: CC BY 4.0 | White Chaunsa Late, Multan, Pakistan.

Kelas yang dipakai: unripe, fully ripe, overripe. Semi-ripe/perished dikeluarkan.

Gambar valid sebelum deduplikasi: 3087; duplikat identik dibuang: 0; gambar rusak: 0; gambar digunakan: 3087.

Split aktual: train=2162 (70.0%), val=463 (15.0%), test=462 (15.0%)

Grup split: 2327; grouping pHash threshold=4; ID buah tersedia=False.

Model: mobilenetv4_conv_small.e2400_r224_in1k, pralatih ImageNet (timm), classifier 3 kelas, input 224x224.

Training: seed=42, batch=32, AdamW, cross-entropy; 3 epoch classifier (lr=0.001) + 7 epoch fine-tuning (backbone lr=3e-05, classifier lr=0.0003).

Augmentasi kondisi kedua: brightness +/-15%, contrast +/-15%, hanya training.

Pemilihan checkpoint: validation macro F1 tertinggi; tie berdasarkan loss lebih rendah.

## Hasil pada validation (hasil awal)

- baseline: accuracy=0.9806, macro F1=0.9768, weighted F1=0.9806; epoch terbaik=10; epoch selesai=10; waktu training=63.6 menit.

- brightness_contrast: accuracy=0.9719, macro F1=0.9665, weighted F1=0.9719; epoch terbaik=10; epoch selesai=10; waktu training=63.5 menit.

## Keterbatasan dan pekerjaan berikutnya

Satu seed per kondisi. pHash adalah heuristik dan tidak membuktikan independensi antarbuah. Foto buah/sesi yang sama mungkin masih berkorelasi jika ID tidak tersedia. Satu varietas dari Pakistan belum mewakili variasi mangga UMKM Indonesia. Label berasal dari dataset dan belum diverifikasi melalui uji kematangan internal.

Langkah berikutnya: audit grup dan label, ulangi beberapa seed, kunci konfigurasi, evaluasi test sekali, lalu uji foto eksternal pada pencahayaan dan varietas berbeda.

Test belum dievaluasi oleh sel perbandingan ini. Jangan menyebut hasil validation sebagai test accuracy.